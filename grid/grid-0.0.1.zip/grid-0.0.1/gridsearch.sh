java -cp "lib/*" com.github.joshuaar.grid.Main $@
